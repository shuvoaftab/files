<?php

namespace FluentMail\Includes\Core;

class BindingResolutionException extends \Exception {}
