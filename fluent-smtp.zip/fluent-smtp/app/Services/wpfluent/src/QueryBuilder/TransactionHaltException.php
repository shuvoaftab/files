<?php

namespace WpFluent\QueryBuilder;

class TransactionHaltException extends \Exception
{
}
