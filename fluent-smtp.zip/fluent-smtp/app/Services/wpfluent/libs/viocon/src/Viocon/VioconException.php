<?php namespace Viocon;


class VioconException extends \Exception
{

}